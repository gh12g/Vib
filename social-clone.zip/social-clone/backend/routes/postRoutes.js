const express = require('express');
const { createPost, getPosts, likePost, commentPost } = require('../controllers/postController');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');
const router = express.Router();

router.post('/', auth, upload.single('image'), createPost);
router.get('/', auth, getPosts);
router.put('/:id/like', auth, likePost);
router.post('/:id/comment', auth, commentPost);

module.exports = router;