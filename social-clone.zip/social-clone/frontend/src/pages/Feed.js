import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Post from '../components/Post';
import PostForm from '../components/PostForm';

const Feed = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const res = await axios.get('http://localhost:5000/api/posts');
      setPosts(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: '1rem' }}>
      <PostForm onPostCreated={fetchPosts} />
      {loading ? (
        <p>جاري التحميل...</p>
      ) : (
        posts.map(post => <Post key={post._id} post={post} onUpdate={fetchPosts} />)
      )}
    </div>
  );
};

export default Feed;