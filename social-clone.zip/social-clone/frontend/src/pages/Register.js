import React, { useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthContext from '../context/AuthContext';

const Register = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { register } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await register(username, email, password);
      navigate('/');
    } catch (err) {
      console.error(err);
      alert('فشل التسجيل');
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: 'auto', marginTop: '2rem' }}>
      <h2>تسجيل حساب جديد</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="اسم المستخدم" value={username} onChange={(e) => setUsername(e.target.value)} required style={{ width: '100%', marginBottom: '1rem', padding: '0.5rem' }} />
        <input type="email" placeholder="البريد الإلكتروني" value={email} onChange={(e) => setEmail(e.target.value)} required style={{ width: '100%', marginBottom: '1rem', padding: '0.5rem' }} />
        <input type="password" placeholder="كلمة المرور" value={password} onChange={(e) => setPassword(e.target.value)} required style={{ width: '100%', marginBottom: '1rem', padding: '0.5rem' }} />
        <button type="submit" style={{ width: '100%', padding: '0.5rem' }}>تسجيل</button>
      </form>
      <p>لديك حساب؟ <Link to="/login">سجل دخول</Link></p>
    </div>
  );
};

export default Register;