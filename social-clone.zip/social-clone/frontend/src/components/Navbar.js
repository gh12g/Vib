import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import AuthContext from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);

  return (
    <nav style={{ display: 'flex', justifyContent: 'space-between', padding: '1rem', borderBottom: '1px solid #ccc' }}>
      <Link to="/">Feed</Link>
      <div>
        <span>{user?.username}</span>
        <button onClick={logout} style={{ marginLeft: '1rem' }}>تسجيل خروج</button>
      </div>
    </nav>
  );
};

export default Navbar;