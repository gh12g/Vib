import React, { useContext, useState } from 'react';
import axios from 'axios';
import AuthContext from '../context/AuthContext';

const Post = ({ post, onUpdate }) => {
  const { user } = useContext(AuthContext);
  const [commentText, setCommentText] = useState('');

  const handleLike = async () => {
    await axios.put(`http://localhost:5000/api/posts/${post._id}/like`);
    onUpdate();
  };

  const handleComment = async (e) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    await axios.post(`http://localhost:5000/api/posts/${post._id}/comment`, { text: commentText });
    setCommentText('');
    onUpdate();
  };

  const isLiked = post.likes.includes(user?._id);

  return (
    <div style={{ border: '1px solid #ccc', marginBottom: '1rem', padding: '1rem', borderRadius: '8px' }}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
        <img src={post.user.avatar || 'https://via.placeholder.com/40'} alt="avatar" style={{ width: 40, height: 40, borderRadius: '50%', marginRight: '0.5rem' }} />
        <strong>{post.user.username}</strong>
      </div>
      <img src={post.imageUrl} alt="post" style={{ width: '100%', maxHeight: '400px', objectFit: 'cover', borderRadius: '4px' }} />
      <p>{post.caption}</p>
      <button onClick={handleLike} style={{ marginRight: '1rem' }}>
        {isLiked ? '❤️' : '🤍'} {post.likes.length}
      </button>
      <div>
        {post.comments.map(comment => (
          <div key={comment._id} style={{ marginTop: '0.5rem' }}>
            <strong>{comment.user.username}</strong>: {comment.text}
          </div>
        ))}
        <form onSubmit={handleComment} style={{ marginTop: '0.5rem' }}>
          <input
            type="text"
            placeholder="أضف تعليقاً..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            style={{ width: '80%', padding: '0.3rem' }}
          />
          <button type="submit">إرسال</button>
        </form>
      </div>
    </div>
  );
};

export default Post;