import React, { useState } from 'react';
import axios from 'axios';

const PostForm = ({ onPostCreated }) => {
  const [caption, setCaption] = useState('');
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!image) return alert('اختر صورة أولاً');
    setLoading(true);
    const formData = new FormData();
    formData.append('caption', caption);
    formData.append('image', image);

    try {
      const res = await axios.post('http://localhost:5000/api/posts', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      onPostCreated(res.data);
      setCaption('');
      setImage(null);
      document.getElementById('imageInput').value = '';
    } catch (err) {
      console.error(err);
      alert('فشل نشر المنشور');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ border: '1px solid #ccc', padding: '1rem', marginBottom: '1rem' }}>
      <input
        type="text"
        placeholder="اكتب وصفاً..."
        value={caption}
        onChange={(e) => setCaption(e.target.value)}
        style={{ width: '100%', marginBottom: '0.5rem', padding: '0.5rem' }}
      />
      <input
        id="imageInput"
        type="file"
        accept="image/*"
        onChange={(e) => setImage(e.target.files[0])}
        style={{ marginBottom: '0.5rem' }}
      />
      <button type="submit" disabled={loading}>{loading ? 'جاري النشر...' : 'نشر'}</button>
    </form>
  );
};

export default PostForm;